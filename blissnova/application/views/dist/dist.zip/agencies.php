<?php include 'header.php';?>




<style>
     .section-heading{
        margin:35px 2px;
        font-size:40px !important;
    }
    .agency-container{
        margin:10px;
        margin-bottom:30px;
    }
    .card{
        border: 2px solid #686BCB;
        background-color: var(--bg-light-1);
        box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
        border-radius:10px !important;
    }
    .card-header{
        padding-top:25px !important;
    }
    .card-title{
        padding-top:10px;
        padding-bottom:10px;
        background-color:#686BCB;
        color:#fff;
    }
    .card-body{
        padding:6px;
        padding-top:15px !important;
    }
    
    .header.-dark .header__menu .icon {
    color: var(--bg-dark-2);
}

    @media screen and (max-width:500px){
        
        .agency-container .col-lg-6{
            margin: 1px !important;
        margin-bottom:20px !important;
    }
    
    }
    
   
    
</style>






<div class="row justify-content-center text-center agency-wrapper">
            <div class="col-lg-7">
              <div class="sectionHeading -lg">
                <h3 class="sectionHeading__title section-heading">
                  Agencies
                </h3>
              </div>
            </div>
          
</div>

       <div style="margin:70px 10px !important;">
                <h1 style="color:#5D61E2;" class="text-center">Coming Soon.....</h1>
            </div>


    <!--<div class="row agency-container">-->
        <!--Card 1-->
    <!--    <div class="col-lg-6 col-md-6">-->
    <!--        <div class="card">-->
    <!--            <div class="card-header text-center">-->
    <!--                <h5 class="card-title">Department Store</h5>-->
    <!--            </div>-->
    <!--            <div class="card-body">-->
    <!--                <div style="margin-bottom:10px;" class="d-flex justify-content-center">-->
    <!--                    <img style="height:50px;" src="<?=BASEURL?>assets/images/location.png">-->
    <!--                </div>-->
    <!--                <div class="text-center">-->
    <!--                    <address>DEPARTMENTAL STORE, SAKHER BAZAR KMC SUPPER MARKET, STALL NO 16 ,27, 28<br>-->
    <!--                    SAKHERBAZAR<br>-->
    <!--                    MANNARAJA80@GMAIL.COM<br>-->
    <!--                    9007808268<br>-->
    <!--                    KOLKATA<br>-->
    <!--                    WEST BENGAL<br>-->
    <!--                    700008</address>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
        <!--Card-2-->
    <!--     <div class="col-lg-6 col-md-6">-->
    <!--        <div class="card">-->
    <!--            <div class="card-header text-center">-->
    <!--                <h5 class="card-title">Main Store</h5>-->
    <!--            </div>-->
    <!--            <div class="card-body">-->
    <!--                  <div style="margin-bottom:10px;" class="d-flex justify-content-center">-->
    <!--                    <img style="height:50px;" src="<?=BASEURL?>assets/images/location.png">-->
    <!--                </div>-->
    <!--                <div class="text-center">-->
    <!--                    <address>DEPARTMENTAL STORE, SAKHER BAZAR KMC SUPPER MARKET, STALL NO 16 ,27, 28<br>-->
    <!--                    SAKHERBAZAR<br>-->
    <!--                    MANNARAJA80@GMAIL.COM<br>-->
    <!--                    9007808268<br>-->
    <!--                    KOLKATA<br>-->
    <!--                    WEST BENGAL<br>-->
    <!--                    700008</address>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    
<!--Row Ends here-->









<?php include 'footer.php';?>